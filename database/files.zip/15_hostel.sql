-- =====================================================================
-- 15_hostel.sql
-- Layer 7 — Optional Module: Hostel
-- Depends on: 14_library.sql
-- =====================================================================

-- ---------------------------------------------------------------------
-- hostel_blocks
-- ---------------------------------------------------------------------
CREATE TABLE hostel_blocks (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id      UUID NOT NULL REFERENCES tenants(id),
    name           VARCHAR(100) NOT NULL,
    warden_id      UUID REFERENCES users(id),
    gender         gender NOT NULL,
    total_rooms    INTEGER NOT NULL DEFAULT 0
);

-- ---------------------------------------------------------------------
-- hostel_rooms
-- ---------------------------------------------------------------------
CREATE TABLE hostel_rooms (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    block_id       UUID NOT NULL REFERENCES hostel_blocks(id) ON DELETE CASCADE,
    tenant_id      UUID NOT NULL REFERENCES tenants(id),
    room_number    VARCHAR(20) NOT NULL,
    capacity       INTEGER NOT NULL,
    occupied       INTEGER NOT NULL DEFAULT 0,
    floor          INTEGER,
    CONSTRAINT uq_hostel_rooms UNIQUE (block_id, room_number)
);

CREATE INDEX idx_hostel_rooms_block_id ON hostel_rooms (block_id);

-- ---------------------------------------------------------------------
-- hostel_allotments
-- ---------------------------------------------------------------------
CREATE TABLE hostel_allotments (
    id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id          UUID NOT NULL REFERENCES tenants(id),
    room_id            UUID NOT NULL REFERENCES hostel_rooms(id),
    student_id         UUID NOT NULL REFERENCES users(id),
    academic_year_id   UUID NOT NULL REFERENCES academic_years(id),
    bed_number         VARCHAR(10),
    allotted_at        DATE NOT NULL DEFAULT CURRENT_DATE,
    vacated_at         DATE,
    status             allotment_status NOT NULL DEFAULT 'ACTIVE'
);

CREATE INDEX idx_hostel_allotments_student_id ON hostel_allotments (student_id);
CREATE INDEX idx_hostel_allotments_room_id    ON hostel_allotments (room_id);

-- Only one ACTIVE allotment per student
CREATE UNIQUE INDEX uq_hostel_allotments_active_student
    ON hostel_allotments (student_id) WHERE status = 'ACTIVE';

-- ---------------------------------------------------------------------
-- hostel_attendance
-- ---------------------------------------------------------------------
-- Note: source design listed status values PRESENT/ABSENT/ON_LEAVE for this
-- table, but reuses the attendance_status enum (PRESENT/ABSENT/LATE/EXCUSED).
-- EXCUSED is used here in place of ON_LEAVE. Adjust if you'd rather add a
-- dedicated enum.
CREATE TABLE hostel_attendance (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id      UUID NOT NULL REFERENCES tenants(id),
    student_id     UUID NOT NULL REFERENCES users(id),
    room_id        UUID NOT NULL REFERENCES hostel_rooms(id),
    date           DATE NOT NULL,
    status         attendance_status NOT NULL,
    marked_by      UUID REFERENCES users(id),
    CONSTRAINT uq_hostel_attendance UNIQUE (student_id, date)
);

CREATE INDEX idx_hostel_attendance_date ON hostel_attendance (date);

-- ---------------------------------------------------------------------
-- hostel_leave_requests
-- ---------------------------------------------------------------------
CREATE TABLE hostel_leave_requests (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id      UUID NOT NULL REFERENCES tenants(id),
    student_id     UUID NOT NULL REFERENCES users(id),
    from_date      DATE NOT NULL,
    to_date        DATE NOT NULL,
    reason         TEXT NOT NULL,
    status         leave_status NOT NULL DEFAULT 'PENDING',
    reviewed_by    UUID REFERENCES users(id),
    reviewed_at    TIMESTAMPTZ,
    created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_hostel_leave_requests_student_id ON hostel_leave_requests (student_id);

-- ---------------------------------------------------------------------
-- hostel_complaints
-- ---------------------------------------------------------------------
CREATE TABLE hostel_complaints (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id      UUID NOT NULL REFERENCES tenants(id),
    student_id     UUID NOT NULL REFERENCES users(id),
    room_id        UUID REFERENCES hostel_rooms(id),
    category       VARCHAR(50) NOT NULL,
    description    TEXT NOT NULL,
    status         complaint_status NOT NULL DEFAULT 'OPEN',
    resolved_by    UUID REFERENCES users(id),
    resolved_at    TIMESTAMPTZ,
    created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_hostel_complaints_student_id ON hostel_complaints (student_id);
CREATE INDEX idx_hostel_complaints_status     ON hostel_complaints (status);
