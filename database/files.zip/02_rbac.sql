-- =====================================================================
-- 02_rbac.sql
-- Layer 2 — RBAC tables
-- Depends on: 00_extensions_and_enums.sql, 01_platform_core.sql
-- Migration order: modules, roles, permissions, users, tenant_modules,
--                   role_assignments, user_sessions
-- =====================================================================

-- ---------------------------------------------------------------------
-- modules
-- ---------------------------------------------------------------------
CREATE TABLE modules (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    key         VARCHAR(50)  NOT NULL,
    name        VARCHAR(100) NOT NULL,
    description TEXT,
    is_core     BOOLEAN      NOT NULL DEFAULT FALSE,
    icon        VARCHAR(50),
    sort_order  INTEGER      NOT NULL DEFAULT 0,
    CONSTRAINT uq_modules_key UNIQUE (key)
);

-- ---------------------------------------------------------------------
-- roles
-- ---------------------------------------------------------------------
CREATE TABLE roles (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name         VARCHAR(100) NOT NULL,
    label        VARCHAR(100) NOT NULL,
    scope_level  scope_level  NOT NULL,
    is_platform  BOOLEAN      NOT NULL DEFAULT FALSE,
    is_optional  BOOLEAN      NOT NULL DEFAULT FALSE,
    module_key   VARCHAR(50)  REFERENCES modules(key),
    description  TEXT,
    CONSTRAINT uq_roles_name UNIQUE (name)
);

-- ---------------------------------------------------------------------
-- permissions
-- ---------------------------------------------------------------------
CREATE TABLE permissions (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    role_id     UUID NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
    module_key  VARCHAR(50) NOT NULL,
    action      permission_action NOT NULL,
    scope       permission_scope  NOT NULL,
    CONSTRAINT uq_permissions_role_module_action UNIQUE (role_id, module_key, action)
);

CREATE INDEX idx_permissions_role_id ON permissions (role_id);

-- ---------------------------------------------------------------------
-- users
-- ---------------------------------------------------------------------
CREATE TABLE users (
    id                       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id                UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    name                     VARCHAR(255) NOT NULL,
    email                    VARCHAR(255),
    phone                    VARCHAR(20),
    password_hash            TEXT,
    avatar_url               TEXT,
    gender                   gender,
    date_of_birth            DATE,
    address                  TEXT,
    employee_code            VARCHAR(50),
    student_roll_no          VARCHAR(50),
    is_active                BOOLEAN NOT NULL DEFAULT TRUE,
    email_verified_at        TIMESTAMPTZ,
    phone_verified_at        TIMESTAMPTZ,
    last_login_at            TIMESTAMPTZ,
    password_reset_token     VARCHAR(255),
    password_reset_expires   TIMESTAMPTZ,
    created_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted_at               TIMESTAMPTZ
);

CREATE UNIQUE INDEX uq_users_tenant_email
    ON users (tenant_id, email) WHERE email IS NOT NULL;
CREATE UNIQUE INDEX uq_users_tenant_roll_no
    ON users (tenant_id, student_roll_no) WHERE student_roll_no IS NOT NULL;
CREATE INDEX idx_users_tenant_id  ON users (tenant_id);
CREATE INDEX idx_users_email      ON users (email) WHERE email IS NOT NULL;
CREATE INDEX idx_users_is_active  ON users (tenant_id, is_active);
CREATE INDEX idx_users_deleted_at ON users (deleted_at) WHERE deleted_at IS NULL;

-- ---------------------------------------------------------------------
-- tenant_modules
-- ---------------------------------------------------------------------
CREATE TABLE tenant_modules (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id    UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    module_key   VARCHAR(50) NOT NULL REFERENCES modules(key),
    is_enabled   BOOLEAN NOT NULL DEFAULT FALSE,
    enabled_at   TIMESTAMPTZ,
    enabled_by   UUID REFERENCES users(id),
    disabled_at  TIMESTAMPTZ,
    disabled_by  UUID REFERENCES users(id),
    CONSTRAINT uq_tenant_modules_tenant_module UNIQUE (tenant_id, module_key)
);

CREATE INDEX idx_tenant_modules_tenant_id ON tenant_modules (tenant_id);
CREATE INDEX idx_tenant_modules_enabled   ON tenant_modules (tenant_id, is_enabled);

-- ---------------------------------------------------------------------
-- role_assignments
-- ---------------------------------------------------------------------
CREATE TABLE role_assignments (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id      UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    role_id      UUID NOT NULL REFERENCES roles(id),
    tenant_id    UUID NOT NULL REFERENCES tenants(id),
    scope_id     UUID,
    scope_type   VARCHAR(50),
    assigned_by  UUID REFERENCES users(id),
    assigned_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at   TIMESTAMPTZ,
    is_active    BOOLEAN NOT NULL DEFAULT TRUE,
    CONSTRAINT uq_role_assignments UNIQUE (user_id, role_id, tenant_id, scope_id)
);

CREATE INDEX idx_role_assignments_user_id     ON role_assignments (user_id);
CREATE INDEX idx_role_assignments_tenant_role ON role_assignments (tenant_id, role_id);
CREATE INDEX idx_role_assignments_scope_id    ON role_assignments (scope_id) WHERE scope_id IS NOT NULL;

-- ---------------------------------------------------------------------
-- user_sessions
-- ---------------------------------------------------------------------
CREATE TABLE user_sessions (
    id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id              UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    refresh_token_hash   VARCHAR(255) NOT NULL,
    device_info          TEXT,
    ip_address           INET,
    expires_at           TIMESTAMPTZ NOT NULL,
    revoked_at           TIMESTAMPTZ,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_user_sessions_refresh_token UNIQUE (refresh_token_hash)
);

CREATE INDEX idx_user_sessions_user_id    ON user_sessions (user_id);
CREATE INDEX idx_user_sessions_expires_at ON user_sessions (expires_at);
