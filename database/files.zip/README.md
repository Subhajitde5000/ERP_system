# ERP + LMS Database — PostgreSQL 18 SQL Files

Generated from `database_design_complete.md`. Tested end-to-end against a
live PostgreSQL instance — every file below applies cleanly, in order,
with zero errors (99 tables, 45 enum types, all FKs/indexes intact).

## How to run

Run the files **in this exact numeric order**, one by one, against your
target database:

```bash
psql -U your_user -d your_db -f 00_extensions_and_enums.sql
psql -U your_user -d your_db -f 01_platform_core.sql
psql -U your_user -d your_db -f 02_rbac.sql
psql -U your_user -d your_db -f 03_institution_structure.sql
psql -U your_user -d your_db -f 04_attendance.sql
psql -U your_user -d your_db -f 05_examination.sql
psql -U your_user -d your_db -f 06_assignment.sql
psql -U your_user -d your_db -f 07_notice_board.sql
psql -U your_user -d your_db -f 08_discussion_forum.sql
psql -U your_user -d your_db -f 09_content_upload.sql
psql -U your_user -d your_db -f 10_results_grade_cards.sql
psql -U your_user -d your_db -f 11_timetable.sql
psql -U your_user -d your_db -f 12_finance.sql
psql -U your_user -d your_db -f 13_support_tickets.sql
psql -U your_user -d your_db -f 14_library.sql
psql -U your_user -d your_db -f 15_hostel.sql
psql -U your_user -d your_db -f 16_transport.sql
psql -U your_user -d your_db -f 17_placement.sql
psql -U your_user -d your_db -f 18_hr.sql
psql -U your_user -d your_db -f 19_admission.sql
psql -U your_user -d your_db -f 20_inventory.sql
psql -U your_user -d your_db -f 21_notifications_and_audit.sql
```

Or, to run everything in one shot instead of one-by-one:

```bash
for f in *.sql; do psql -U your_user -d your_db -f "$f" || break; done
```

(the numeric filename prefixes guarantee correct order with `for f in *.sql`)

## Order matches your migration plan, with two fixes

1. **Transport module reordered.** Your design listed `transport_routes`
   before `vehicles`/`drivers`, but `transport_routes` has foreign keys
   into both. File `16_transport.sql` creates `vehicles` → `drivers` →
   `transport_routes` → `transport_stops` → `student_transport`, so every
   FK target exists before it's referenced.
2. **`support_tickets` moved after `users`.** It references `users.id`
   (raised_by), so it can't be created in the platform layer before RBAC
   exists — it now sits in its own file (`13_support_tickets.sql`) right
   after Finance, matching your migration-order list.

## Two things worth double-checking against your own intent

- **`hostel_attendance.status`** — your table spec described values
  `PRESENT / ABSENT / ON_LEAVE`, but the column type you specified reuses
  the existing `attendance_status` enum (`PRESENT / ABSENT / LATE /
  EXCUSED`). I kept the enum as declared and used `EXCUSED` in place of
  `ON_LEAVE`. If you want a dedicated `hostel_attendance_status` enum
  instead, say so and I'll split it out.
- **`submission_reviews`** — this table appears in your schema overview
  list (#36) but no column spec was given anywhere in the doc, so it
  isn't included here. Tell me the columns you want and I'll add
  `06b_submission_reviews.sql`.

## What's included

- Every `CREATE EXTENSION`, `CREATE TYPE` (45 enums), `CREATE TABLE` (99
  tables), primary/foreign keys, `UNIQUE` constraints, and every index
  from your Index Strategy section (including partial/conditional
  indexes like "one current academic year" and "one active hostel
  allotment per student").
- `gen_random_uuid()` for all UUID primary keys (native in PostgreSQL 13+,
  `pgcrypto` enabled anyway for compatibility).
- Polymorphic/array columns (`target_id`, `scope_id`, `entity_id`,
  `application_ids`, etc.) intentionally have **no** FK constraint, same
  as your design — that's correct, not a bug.

## Not included (by design)

- Row-level security policies, triggers, and seed data — say the word if
  you want those generated next.
