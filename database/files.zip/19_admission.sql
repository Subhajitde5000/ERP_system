-- =====================================================================
-- 19_admission.sql
-- Layer 7 — Optional Module: Admission
-- Depends on: 18_hr.sql
-- =====================================================================

-- ---------------------------------------------------------------------
-- admission_cycles
-- ---------------------------------------------------------------------
CREATE TABLE admission_cycles (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id      UUID NOT NULL REFERENCES tenants(id),
    name           VARCHAR(100) NOT NULL,
    academic_year_id UUID NOT NULL REFERENCES academic_years(id),
    opens_at       TIMESTAMPTZ NOT NULL,
    closes_at      TIMESTAMPTZ NOT NULL,
    status         admission_cycle_status NOT NULL DEFAULT 'UPCOMING'
);

-- ---------------------------------------------------------------------
-- admission_applications
-- ---------------------------------------------------------------------
CREATE TABLE admission_applications (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id         UUID NOT NULL REFERENCES tenants(id),
    cycle_id          UUID NOT NULL REFERENCES admission_cycles(id),
    applicant_name    VARCHAR(255) NOT NULL,
    email             VARCHAR(255),
    phone             VARCHAR(20),
    department_id     UUID REFERENCES departments(id),
    class_applied_for VARCHAR(100),
    application_number VARCHAR(50) NOT NULL,
    status            admission_status NOT NULL DEFAULT 'SUBMITTED',
    submitted_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    reviewed_by       UUID REFERENCES users(id),
    reviewed_at       TIMESTAMPTZ,
    CONSTRAINT uq_admission_applications_number UNIQUE (tenant_id, application_number)
);

CREATE INDEX idx_admission_applications_cycle_id ON admission_applications (cycle_id);
CREATE INDEX idx_admission_applications_status   ON admission_applications (status);

-- ---------------------------------------------------------------------
-- application_documents
-- ---------------------------------------------------------------------
CREATE TABLE application_documents (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    application_id UUID NOT NULL REFERENCES admission_applications(id) ON DELETE CASCADE,
    document_type  VARCHAR(50) NOT NULL,
    file_key       TEXT NOT NULL,
    uploaded_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_application_documents_application_id ON application_documents (application_id);

-- ---------------------------------------------------------------------
-- merit_lists
-- ---------------------------------------------------------------------
CREATE TABLE merit_lists (
    id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id          UUID NOT NULL REFERENCES tenants(id),
    cycle_id           UUID NOT NULL REFERENCES admission_cycles(id),
    title              VARCHAR(255) NOT NULL,
    application_ids    UUID[] NOT NULL,
    published_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    published_by       UUID NOT NULL REFERENCES users(id)
);
