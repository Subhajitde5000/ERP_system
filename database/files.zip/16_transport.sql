-- =====================================================================
-- 16_transport.sql
-- Layer 7 — Optional Module: Transport
-- Depends on: 15_hostel.sql
--
-- NOTE: the source design lists transport_routes (#67) before vehicles
-- (#69) and drivers (#70), but transport_routes has FKs to both. Table
-- order below is corrected so every FK target already exists.
-- =====================================================================

-- ---------------------------------------------------------------------
-- vehicles
-- ---------------------------------------------------------------------
CREATE TABLE vehicles (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id         UUID NOT NULL REFERENCES tenants(id),
    registration_no   VARCHAR(30) NOT NULL,
    type              VARCHAR(50) NOT NULL,
    capacity          INTEGER NOT NULL,
    insurance_expiry  DATE,
    permit_expiry     DATE,
    is_active         BOOLEAN NOT NULL DEFAULT TRUE,
    CONSTRAINT uq_vehicles_registration UNIQUE (tenant_id, registration_no)
);

-- ---------------------------------------------------------------------
-- drivers
-- ---------------------------------------------------------------------
CREATE TABLE drivers (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id         UUID NOT NULL REFERENCES tenants(id),
    name              VARCHAR(255) NOT NULL,
    phone             VARCHAR(20) NOT NULL,
    license_number    VARCHAR(50) NOT NULL,
    license_expiry    DATE,
    is_active         BOOLEAN NOT NULL DEFAULT TRUE
);

-- ---------------------------------------------------------------------
-- transport_routes
-- ---------------------------------------------------------------------
CREATE TABLE transport_routes (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id      UUID NOT NULL REFERENCES tenants(id),
    name           VARCHAR(100) NOT NULL,
    vehicle_id     UUID REFERENCES vehicles(id),
    driver_id      UUID REFERENCES drivers(id),
    monthly_fee    NUMERIC(10,2) NOT NULL,
    is_active      BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE INDEX idx_transport_routes_vehicle_id ON transport_routes (vehicle_id);
CREATE INDEX idx_transport_routes_driver_id  ON transport_routes (driver_id);

-- ---------------------------------------------------------------------
-- transport_stops
-- ---------------------------------------------------------------------
CREATE TABLE transport_stops (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    route_id       UUID NOT NULL REFERENCES transport_routes(id) ON DELETE CASCADE,
    tenant_id      UUID NOT NULL REFERENCES tenants(id),
    name           VARCHAR(255) NOT NULL,
    sequence       INTEGER NOT NULL,
    pickup_time    TIME,
    latitude       NUMERIC(9,6),
    longitude      NUMERIC(9,6)
);

CREATE INDEX idx_transport_stops_route_id ON transport_stops (route_id);

-- ---------------------------------------------------------------------
-- student_transport
-- ---------------------------------------------------------------------
CREATE TABLE student_transport (
    id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id          UUID NOT NULL REFERENCES tenants(id),
    student_id         UUID NOT NULL REFERENCES users(id),
    route_id           UUID NOT NULL REFERENCES transport_routes(id),
    stop_id            UUID NOT NULL REFERENCES transport_stops(id),
    academic_year_id   UUID NOT NULL REFERENCES academic_years(id),
    is_active          BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE INDEX idx_student_transport_student_id ON student_transport (student_id);

-- Only one active transport assignment per student per academic year
CREATE UNIQUE INDEX uq_student_transport_active
    ON student_transport (student_id, academic_year_id) WHERE is_active = TRUE;
