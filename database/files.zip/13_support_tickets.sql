-- =====================================================================
-- 13_support_tickets.sql
-- Layer 6 — Platform ERP Tables (Support)
-- Depends on: 12_finance.sql
-- =====================================================================

-- ---------------------------------------------------------------------
-- support_tickets
-- ---------------------------------------------------------------------
CREATE TABLE support_tickets (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id      UUID NOT NULL REFERENCES tenants(id),
    raised_by      UUID NOT NULL REFERENCES users(id),
    subject        VARCHAR(255) NOT NULL,
    description    TEXT NOT NULL,
    priority       ticket_priority NOT NULL DEFAULT 'MEDIUM',
    status         ticket_status NOT NULL DEFAULT 'OPEN',
    assigned_to    UUID REFERENCES platform_users(id),
    resolved_at    TIMESTAMPTZ,
    created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_support_tickets_tenant_id   ON support_tickets (tenant_id);
CREATE INDEX idx_support_tickets_status      ON support_tickets (status);
CREATE INDEX idx_support_tickets_assigned_to ON support_tickets (assigned_to);
