-- =====================================================================
-- 01_platform_core.sql
-- Layer 1 — Platform tables (no dependency on RBAC users yet)
-- Depends on: 00_extensions_and_enums.sql
-- =====================================================================

-- ---------------------------------------------------------------------
-- plans
-- ---------------------------------------------------------------------
CREATE TABLE plans (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name             VARCHAR(100)   NOT NULL,
    slug             VARCHAR(50)    NOT NULL,
    max_students     INTEGER        NOT NULL,
    max_teachers     INTEGER        NOT NULL,
    max_storage_gb   INTEGER        NOT NULL DEFAULT 10,
    price_monthly    NUMERIC(10,2)  NOT NULL,
    price_yearly     NUMERIC(10,2)  NOT NULL,
    currency         VARCHAR(3)     NOT NULL DEFAULT 'INR',
    allowed_modules  TEXT[]         NOT NULL DEFAULT '{}',
    is_active        BOOLEAN        NOT NULL DEFAULT TRUE,
    created_at       TIMESTAMPTZ    NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ    NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_plans_slug UNIQUE (slug)
);

-- ---------------------------------------------------------------------
-- platform_users
-- ---------------------------------------------------------------------
CREATE TABLE platform_users (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name           VARCHAR(255)   NOT NULL,
    email          VARCHAR(255)   NOT NULL,
    password_hash  TEXT           NOT NULL,
    platform_role  platform_role  NOT NULL,
    is_active      BOOLEAN        NOT NULL DEFAULT TRUE,
    last_login_at  TIMESTAMPTZ,
    created_at     TIMESTAMPTZ    NOT NULL DEFAULT NOW(),
    updated_at     TIMESTAMPTZ    NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_platform_users_email UNIQUE (email)
);

-- ---------------------------------------------------------------------
-- tenants
-- ---------------------------------------------------------------------
CREATE TABLE tenants (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name           VARCHAR(255)   NOT NULL,
    slug           VARCHAR(100)   NOT NULL,
    type           tenant_type    NOT NULL,
    plan_id        UUID           REFERENCES plans(id),
    logo_url       TEXT,
    address        TEXT,
    city           VARCHAR(100),
    state          VARCHAR(100),
    country        VARCHAR(100)   NOT NULL DEFAULT 'India',
    pincode        VARCHAR(20),
    phone          VARCHAR(20),
    email          VARCHAR(255),
    website        VARCHAR(255),
    timezone       VARCHAR(50)    NOT NULL DEFAULT 'Asia/Kolkata',
    is_active      BOOLEAN        NOT NULL DEFAULT TRUE,
    trial_ends_at  TIMESTAMPTZ,
    created_at     TIMESTAMPTZ    NOT NULL DEFAULT NOW(),
    updated_at     TIMESTAMPTZ    NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_tenants_slug UNIQUE (slug)
);

CREATE INDEX idx_tenants_plan_id   ON tenants (plan_id);
CREATE INDEX idx_tenants_is_active ON tenants (is_active);

-- ---------------------------------------------------------------------
-- tenant_settings
-- ---------------------------------------------------------------------
CREATE TABLE tenant_settings (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id   UUID        NOT NULL REFERENCES tenants(id),
    key         VARCHAR(100) NOT NULL,
    value       TEXT        NOT NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_tenant_settings_tenant_key UNIQUE (tenant_id, key)
);

-- ---------------------------------------------------------------------
-- subscriptions
-- ---------------------------------------------------------------------
CREATE TABLE subscriptions (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id           UUID   NOT NULL REFERENCES tenants(id),
    plan_id             UUID   NOT NULL REFERENCES plans(id),
    status              subscription_status NOT NULL,
    starts_at           TIMESTAMPTZ NOT NULL,
    ends_at             TIMESTAMPTZ,
    amount              NUMERIC(10,2) NOT NULL,
    currency            VARCHAR(3) NOT NULL DEFAULT 'INR',
    payment_reference   VARCHAR(255),
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_subscriptions_tenant_id ON subscriptions (tenant_id);
CREATE INDEX idx_subscriptions_plan_id   ON subscriptions (plan_id);
