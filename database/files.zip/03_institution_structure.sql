-- =====================================================================
-- 03_institution_structure.sql
-- Layer 3 — Institution structure tables
-- Depends on: 02_rbac.sql
-- =====================================================================

-- ---------------------------------------------------------------------
-- academic_years
-- ---------------------------------------------------------------------
CREATE TABLE academic_years (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id   UUID NOT NULL REFERENCES tenants(id),
    name        VARCHAR(50) NOT NULL,
    start_date  DATE NOT NULL,
    end_date    DATE NOT NULL,
    is_current  BOOLEAN NOT NULL DEFAULT FALSE,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_academic_years_tenant_name UNIQUE (tenant_id, name)
);

-- Only one "current" academic year per tenant
CREATE UNIQUE INDEX uq_one_current_year ON academic_years (tenant_id) WHERE is_current = TRUE;

-- ---------------------------------------------------------------------
-- departments
-- ---------------------------------------------------------------------
CREATE TABLE departments (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id    UUID NOT NULL REFERENCES tenants(id),
    name         VARCHAR(255) NOT NULL,
    code         VARCHAR(20) NOT NULL,
    hod_id       UUID REFERENCES users(id),
    description  TEXT,
    is_active    BOOLEAN NOT NULL DEFAULT TRUE,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_departments_tenant_code UNIQUE (tenant_id, code)
);

CREATE INDEX idx_departments_tenant_id ON departments (tenant_id);
CREATE INDEX idx_departments_hod_id    ON departments (hod_id);

-- ---------------------------------------------------------------------
-- classes
-- ---------------------------------------------------------------------
CREATE TABLE classes (
    id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id          UUID NOT NULL REFERENCES tenants(id),
    department_id      UUID NOT NULL REFERENCES departments(id),
    academic_year_id   UUID NOT NULL REFERENCES academic_years(id),
    name               VARCHAR(100) NOT NULL,
    code               VARCHAR(20) NOT NULL,
    max_strength       INTEGER NOT NULL DEFAULT 60,
    class_teacher_id   UUID REFERENCES users(id),
    room_no            VARCHAR(20),
    is_active          BOOLEAN NOT NULL DEFAULT TRUE,
    created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_classes_tenant_dept_year_code UNIQUE (tenant_id, department_id, academic_year_id, code)
);

CREATE INDEX idx_classes_tenant_id        ON classes (tenant_id);
CREATE INDEX idx_classes_department_id    ON classes (department_id);
CREATE INDEX idx_classes_academic_year_id ON classes (academic_year_id);

-- ---------------------------------------------------------------------
-- subjects
-- ---------------------------------------------------------------------
CREATE TABLE subjects (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES tenants(id),
    class_id        UUID NOT NULL REFERENCES classes(id),
    name            VARCHAR(255) NOT NULL,
    code            VARCHAR(30) NOT NULL,
    subject_type    subject_type NOT NULL,
    credits         INTEGER,
    max_marks       INTEGER NOT NULL DEFAULT 100,
    passing_marks   INTEGER NOT NULL DEFAULT 35,
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_subjects_tenant_class_code UNIQUE (tenant_id, class_id, code)
);

CREATE INDEX idx_subjects_class_id ON subjects (class_id);

-- ---------------------------------------------------------------------
-- teacher_subjects
-- ---------------------------------------------------------------------
CREATE TABLE teacher_subjects (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id        UUID NOT NULL REFERENCES tenants(id),
    teacher_id       UUID NOT NULL REFERENCES users(id),
    subject_id       UUID NOT NULL REFERENCES subjects(id),
    role_in_subject  VARCHAR(50) NOT NULL DEFAULT 'TEACHER',
    assigned_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    assigned_by      UUID REFERENCES users(id),
    CONSTRAINT uq_teacher_subjects UNIQUE (teacher_id, subject_id, role_in_subject)
);

CREATE INDEX idx_teacher_subjects_teacher_id ON teacher_subjects (teacher_id);
CREATE INDEX idx_teacher_subjects_subject_id ON teacher_subjects (subject_id);

-- ---------------------------------------------------------------------
-- student_enrollments
-- ---------------------------------------------------------------------
CREATE TABLE student_enrollments (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id         UUID NOT NULL REFERENCES tenants(id),
    student_id        UUID NOT NULL REFERENCES users(id),
    class_id          UUID NOT NULL REFERENCES classes(id),
    academic_year_id  UUID NOT NULL REFERENCES academic_years(id),
    roll_number       VARCHAR(50),
    enrollment_date   DATE NOT NULL DEFAULT CURRENT_DATE,
    status            enrollment_status NOT NULL DEFAULT 'ACTIVE',
    transferred_to    UUID REFERENCES classes(id),
    created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_enrollments_student_class_year UNIQUE (student_id, class_id, academic_year_id)
);

CREATE INDEX idx_enrollments_student_id       ON student_enrollments (student_id);
CREATE INDEX idx_enrollments_class_id         ON student_enrollments (class_id);
CREATE INDEX idx_enrollments_academic_year_id ON student_enrollments (academic_year_id);

-- ---------------------------------------------------------------------
-- parent_student_links
-- ---------------------------------------------------------------------
CREATE TABLE parent_student_links (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id   UUID NOT NULL REFERENCES tenants(id),
    parent_id   UUID NOT NULL REFERENCES users(id),
    student_id  UUID NOT NULL REFERENCES users(id),
    relation    VARCHAR(50) NOT NULL,
    is_primary  BOOLEAN NOT NULL DEFAULT FALSE,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_parent_student UNIQUE (parent_id, student_id)
);

CREATE INDEX idx_parent_student_parent_id  ON parent_student_links (parent_id);
CREATE INDEX idx_parent_student_student_id ON parent_student_links (student_id);
