-- =====================================================================
-- 18_hr.sql
-- Layer 7 — Optional Module: HR
-- Depends on: 17_placement.sql
-- =====================================================================

-- ---------------------------------------------------------------------
-- staff_profiles
-- ---------------------------------------------------------------------
CREATE TABLE staff_profiles (
    id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id          UUID NOT NULL REFERENCES tenants(id),
    user_id            UUID NOT NULL REFERENCES users(id),
    designation        VARCHAR(100),
    department_id      UUID REFERENCES departments(id),
    employment_type    employment_type NOT NULL,
    date_of_joining    DATE NOT NULL,
    date_of_exit       DATE,
    reporting_to       UUID REFERENCES users(id),
    bank_account_no    VARCHAR(50),
    bank_ifsc          VARCHAR(20),
    pan_number         VARCHAR(20),
    CONSTRAINT uq_staff_profiles_user_id UNIQUE (user_id)
);

CREATE INDEX idx_staff_profiles_department_id ON staff_profiles (department_id);

-- ---------------------------------------------------------------------
-- leave_policies
-- ---------------------------------------------------------------------
CREATE TABLE leave_policies (
    id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id          UUID NOT NULL REFERENCES tenants(id),
    name               VARCHAR(100) NOT NULL,
    days_per_year      INTEGER NOT NULL,
    applies_to         employment_type[] NOT NULL,
    carry_forward      BOOLEAN NOT NULL DEFAULT FALSE
);

-- ---------------------------------------------------------------------
-- leave_requests
-- ---------------------------------------------------------------------
CREATE TABLE leave_requests (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id      UUID NOT NULL REFERENCES tenants(id),
    staff_id       UUID NOT NULL REFERENCES users(id),
    policy_id      UUID NOT NULL REFERENCES leave_policies(id),
    from_date      DATE NOT NULL,
    to_date        DATE NOT NULL,
    reason         TEXT,
    status         leave_status NOT NULL DEFAULT 'PENDING',
    approved_by    UUID REFERENCES users(id),
    approved_at    TIMESTAMPTZ,
    created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_leave_requests_staff_id ON leave_requests (staff_id);

-- ---------------------------------------------------------------------
-- salary_structures
-- ---------------------------------------------------------------------
CREATE TABLE salary_structures (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id         UUID NOT NULL REFERENCES tenants(id),
    staff_id          UUID NOT NULL REFERENCES users(id),
    basic             NUMERIC(12,2) NOT NULL,
    hra               NUMERIC(12,2) NOT NULL DEFAULT 0,
    allowances        NUMERIC(12,2) NOT NULL DEFAULT 0,
    deductions        NUMERIC(12,2) NOT NULL DEFAULT 0,
    gross_salary      NUMERIC(12,2) NOT NULL,
    effective_from    DATE NOT NULL
);

CREATE INDEX idx_salary_structures_staff_id ON salary_structures (staff_id);

-- ---------------------------------------------------------------------
-- payroll_runs
-- ---------------------------------------------------------------------
CREATE TABLE payroll_runs (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id      UUID NOT NULL REFERENCES tenants(id),
    month          SMALLINT NOT NULL,
    year           SMALLINT NOT NULL,
    status         payroll_status NOT NULL DEFAULT 'DRAFT',
    processed_by   UUID REFERENCES users(id),
    processed_at   TIMESTAMPTZ,
    CONSTRAINT uq_payroll_runs UNIQUE (tenant_id, month, year)
);

-- ---------------------------------------------------------------------
-- payslips
-- ---------------------------------------------------------------------
CREATE TABLE payslips (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    payroll_run_id UUID NOT NULL REFERENCES payroll_runs(id),
    tenant_id      UUID NOT NULL REFERENCES tenants(id),
    staff_id       UUID NOT NULL REFERENCES users(id),
    gross_salary   NUMERIC(12,2) NOT NULL,
    deductions     NUMERIC(12,2) NOT NULL DEFAULT 0,
    net_salary     NUMERIC(12,2) NOT NULL,
    days_present   INTEGER,
    file_key       TEXT,
    CONSTRAINT uq_payslips UNIQUE (payroll_run_id, staff_id)
);

CREATE INDEX idx_payslips_staff_id ON payslips (staff_id);

-- ---------------------------------------------------------------------
-- appraisal_cycles
-- ---------------------------------------------------------------------
CREATE TABLE appraisal_cycles (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id      UUID NOT NULL REFERENCES tenants(id),
    name           VARCHAR(100) NOT NULL,
    start_date     DATE NOT NULL,
    end_date       DATE NOT NULL,
    status         appraisal_status NOT NULL DEFAULT 'PLANNED'
);

-- ---------------------------------------------------------------------
-- appraisals
-- ---------------------------------------------------------------------
CREATE TABLE appraisals (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    cycle_id       UUID NOT NULL REFERENCES appraisal_cycles(id),
    tenant_id      UUID NOT NULL REFERENCES tenants(id),
    staff_id       UUID NOT NULL REFERENCES users(id),
    reviewer_id    UUID NOT NULL REFERENCES users(id),
    self_rating    NUMERIC(3,1),
    manager_rating NUMERIC(3,1),
    comments       TEXT,
    status         appraisal_status NOT NULL DEFAULT 'PENDING',
    CONSTRAINT uq_appraisals UNIQUE (cycle_id, staff_id)
);

CREATE INDEX idx_appraisals_staff_id ON appraisals (staff_id);

-- ---------------------------------------------------------------------
-- staff_documents
-- ---------------------------------------------------------------------
CREATE TABLE staff_documents (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id      UUID NOT NULL REFERENCES tenants(id),
    staff_id       UUID NOT NULL REFERENCES users(id),
    document_type  VARCHAR(50) NOT NULL,
    file_key       TEXT NOT NULL,
    uploaded_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expiry_date    DATE
);

CREATE INDEX idx_staff_documents_staff_id ON staff_documents (staff_id);
