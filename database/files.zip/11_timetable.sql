-- =====================================================================
-- 11_timetable.sql
-- Layer 4 — Core Module: Timetable
-- Depends on: 10_results_grade_cards.sql
-- =====================================================================

-- ---------------------------------------------------------------------
-- timetable_slots
-- ---------------------------------------------------------------------
CREATE TABLE timetable_slots (
    id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id          UUID NOT NULL REFERENCES tenants(id),
    class_id           UUID NOT NULL REFERENCES classes(id),
    academic_year_id   UUID NOT NULL REFERENCES academic_years(id),
    day_of_week        SMALLINT NOT NULL,
    period_number      SMALLINT NOT NULL,
    start_time         TIME NOT NULL,
    end_time           TIME NOT NULL,
    subject_id         UUID REFERENCES subjects(id),
    teacher_id         UUID REFERENCES users(id),
    room_no            VARCHAR(20),
    slot_type          slot_type NOT NULL DEFAULT 'CLASS',
    effective_from     DATE NOT NULL,
    effective_to       DATE,
    CONSTRAINT uq_timetable_slots UNIQUE (class_id, day_of_week, period_number, effective_from)
);

CREATE INDEX idx_timetable_class_id    ON timetable_slots (class_id);
CREATE INDEX idx_timetable_teacher_id  ON timetable_slots (teacher_id);
CREATE INDEX idx_timetable_class_day   ON timetable_slots (class_id, day_of_week, period_number);
CREATE INDEX idx_timetable_teacher     ON timetable_slots (teacher_id);

-- ---------------------------------------------------------------------
-- timetable_substitutions
-- ---------------------------------------------------------------------
CREATE TABLE timetable_substitutions (
    id                       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id                UUID NOT NULL REFERENCES tenants(id),
    slot_id                  UUID NOT NULL REFERENCES timetable_slots(id),
    date                     DATE NOT NULL,
    substitute_teacher_id    UUID NOT NULL REFERENCES users(id),
    original_teacher_id      UUID NOT NULL REFERENCES users(id),
    reason                   TEXT,
    arranged_by              UUID REFERENCES users(id),
    created_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_timetable_substitutions UNIQUE (slot_id, date)
);
