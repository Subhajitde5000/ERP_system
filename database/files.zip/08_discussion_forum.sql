-- =====================================================================
-- 08_discussion_forum.sql
-- Layer 4 — Core Module: Discussion Forum
-- Depends on: 07_notice_board.sql
-- =====================================================================

-- ---------------------------------------------------------------------
-- discussion_threads
-- ---------------------------------------------------------------------
CREATE TABLE discussion_threads (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id      UUID NOT NULL REFERENCES tenants(id),
    title          VARCHAR(255) NOT NULL,
    body           TEXT NOT NULL,
    author_id      UUID NOT NULL REFERENCES users(id),
    scope_type     VARCHAR(20) NOT NULL,
    scope_id       UUID NOT NULL,
    tags           TEXT[],
    is_pinned      BOOLEAN NOT NULL DEFAULT FALSE,
    is_locked      BOOLEAN NOT NULL DEFAULT FALSE,
    is_resolved    BOOLEAN NOT NULL DEFAULT FALSE,
    resolved_by    UUID REFERENCES users(id),
    reply_count    INTEGER NOT NULL DEFAULT 0,
    upvote_count   INTEGER NOT NULL DEFAULT 0,
    view_count     INTEGER NOT NULL DEFAULT 0,
    created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted_at     TIMESTAMPTZ
);

CREATE INDEX idx_threads_scope       ON discussion_threads (scope_type, scope_id, created_at DESC);
CREATE INDEX idx_threads_author_id   ON discussion_threads (author_id);
CREATE INDEX idx_threads_created_at  ON discussion_threads (created_at);

-- ---------------------------------------------------------------------
-- discussion_replies
-- ---------------------------------------------------------------------
CREATE TABLE discussion_replies (
    id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id             UUID NOT NULL REFERENCES tenants(id),
    thread_id             UUID NOT NULL REFERENCES discussion_threads(id) ON DELETE CASCADE,
    author_id             UUID NOT NULL REFERENCES users(id),
    body                  TEXT NOT NULL,
    is_accepted_answer    BOOLEAN NOT NULL DEFAULT FALSE,
    upvote_count          INTEGER NOT NULL DEFAULT 0,
    created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted_at            TIMESTAMPTZ
);

CREATE INDEX idx_replies_thread_id  ON discussion_replies (thread_id);
CREATE INDEX idx_replies_author_id  ON discussion_replies (author_id);
CREATE INDEX idx_replies_thread     ON discussion_replies (thread_id, created_at);

-- ---------------------------------------------------------------------
-- discussion_votes
-- ---------------------------------------------------------------------
CREATE TABLE discussion_votes (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id       UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    target_type   VARCHAR(10) NOT NULL,
    target_id     UUID NOT NULL,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_discussion_votes UNIQUE (user_id, target_type, target_id)
);
