-- =====================================================================
-- 14_library.sql
-- Layer 7 — Optional Module: Library
-- Depends on: 13_support_tickets.sql
-- =====================================================================

-- ---------------------------------------------------------------------
-- books
-- ---------------------------------------------------------------------
CREATE TABLE books (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id         UUID NOT NULL REFERENCES tenants(id),
    title             VARCHAR(255) NOT NULL,
    author            VARCHAR(255),
    isbn              VARCHAR(20),
    publisher         VARCHAR(255),
    category          VARCHAR(100),
    edition           VARCHAR(50),
    total_copies      INTEGER NOT NULL DEFAULT 0,
    available_copies  INTEGER NOT NULL DEFAULT 0,
    cover_image_url   TEXT,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_books_tenant_id ON books (tenant_id);
CREATE INDEX idx_books_isbn      ON books (isbn);
CREATE INDEX idx_books_category  ON books (tenant_id, category);

-- ---------------------------------------------------------------------
-- book_copies
-- ---------------------------------------------------------------------
CREATE TABLE book_copies (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    book_id        UUID NOT NULL REFERENCES books(id) ON DELETE CASCADE,
    tenant_id      UUID NOT NULL REFERENCES tenants(id),
    barcode        VARCHAR(50) NOT NULL,
    condition      book_condition NOT NULL DEFAULT 'GOOD',
    is_available   BOOLEAN NOT NULL DEFAULT TRUE,
    CONSTRAINT uq_book_copies_barcode UNIQUE (tenant_id, barcode)
);

CREATE INDEX idx_book_copies_book_id ON book_copies (book_id);

-- ---------------------------------------------------------------------
-- book_issues
-- ---------------------------------------------------------------------
CREATE TABLE book_issues (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id      UUID NOT NULL REFERENCES tenants(id),
    copy_id        UUID NOT NULL REFERENCES book_copies(id),
    user_id        UUID NOT NULL REFERENCES users(id),
    issued_by      UUID NOT NULL REFERENCES users(id),
    issued_at      DATE NOT NULL DEFAULT CURRENT_DATE,
    due_date       DATE NOT NULL,
    returned_at    DATE,
    fine_amount    NUMERIC(8,2) NOT NULL DEFAULT 0,
    fine_paid      BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE INDEX idx_book_issues_user_id ON book_issues (user_id);
CREATE INDEX idx_book_issues_copy_id ON book_issues (copy_id);
CREATE INDEX idx_book_issues_active  ON book_issues (user_id) WHERE returned_at IS NULL;

-- ---------------------------------------------------------------------
-- e_resources
-- ---------------------------------------------------------------------
CREATE TABLE e_resources (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id      UUID NOT NULL REFERENCES tenants(id),
    title          VARCHAR(255) NOT NULL,
    type           VARCHAR(50) NOT NULL,
    url            TEXT NOT NULL,
    category       VARCHAR(100),
    uploaded_by    UUID NOT NULL REFERENCES users(id),
    created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
