-- =====================================================================
-- 20_inventory.sql
-- Layer 7 — Optional Module: Inventory
-- Depends on: 19_admission.sql
-- =====================================================================

-- ---------------------------------------------------------------------
-- inventory_categories
-- ---------------------------------------------------------------------
CREATE TABLE inventory_categories (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id      UUID NOT NULL REFERENCES tenants(id),
    name           VARCHAR(100) NOT NULL,
    parent_id      UUID REFERENCES inventory_categories(id)
);

-- ---------------------------------------------------------------------
-- inventory_items
-- ---------------------------------------------------------------------
CREATE TABLE inventory_items (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id         UUID NOT NULL REFERENCES tenants(id),
    category_id       UUID NOT NULL REFERENCES inventory_categories(id),
    name              VARCHAR(255) NOT NULL,
    sku               VARCHAR(50),
    unit              VARCHAR(20) NOT NULL,
    quantity_in_stock NUMERIC(12,2) NOT NULL DEFAULT 0,
    reorder_level     NUMERIC(12,2) NOT NULL DEFAULT 0,
    unit_price        NUMERIC(10,2),
    CONSTRAINT uq_inventory_items_sku UNIQUE (tenant_id, sku)
);

CREATE INDEX idx_inventory_items_category_id ON inventory_items (category_id);

-- ---------------------------------------------------------------------
-- stock_transactions
-- ---------------------------------------------------------------------
CREATE TABLE stock_transactions (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id      UUID NOT NULL REFERENCES tenants(id),
    item_id        UUID NOT NULL REFERENCES inventory_items(id),
    type           stock_txn_type NOT NULL,
    quantity       NUMERIC(12,2) NOT NULL,
    reference      VARCHAR(255),
    performed_by   UUID NOT NULL REFERENCES users(id),
    created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_stock_transactions_item_id ON stock_transactions (item_id);

-- ---------------------------------------------------------------------
-- vendors
-- ---------------------------------------------------------------------
CREATE TABLE vendors (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id      UUID NOT NULL REFERENCES tenants(id),
    name           VARCHAR(255) NOT NULL,
    contact_person VARCHAR(255),
    phone          VARCHAR(20),
    email          VARCHAR(255),
    address        TEXT
);

-- ---------------------------------------------------------------------
-- purchase_orders
-- ---------------------------------------------------------------------
CREATE TABLE purchase_orders (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id      UUID NOT NULL REFERENCES tenants(id),
    vendor_id      UUID NOT NULL REFERENCES vendors(id),
    po_number      VARCHAR(50) NOT NULL,
    status         po_status NOT NULL DEFAULT 'DRAFT',
    total_amount   NUMERIC(12,2) NOT NULL DEFAULT 0,
    ordered_by     UUID NOT NULL REFERENCES users(id),
    ordered_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    delivered_at   TIMESTAMPTZ,
    CONSTRAINT uq_purchase_orders_po_number UNIQUE (tenant_id, po_number)
);

CREATE INDEX idx_purchase_orders_vendor_id ON purchase_orders (vendor_id);

-- ---------------------------------------------------------------------
-- purchase_order_items
-- ---------------------------------------------------------------------
CREATE TABLE purchase_order_items (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    po_id          UUID NOT NULL REFERENCES purchase_orders(id) ON DELETE CASCADE,
    item_id        UUID NOT NULL REFERENCES inventory_items(id),
    quantity       NUMERIC(12,2) NOT NULL,
    unit_price     NUMERIC(10,2) NOT NULL,
    subtotal       NUMERIC(12,2) NOT NULL
);

CREATE INDEX idx_purchase_order_items_po_id ON purchase_order_items (po_id);
