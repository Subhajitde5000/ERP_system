-- =====================================================================
-- 17_placement.sql
-- Layer 7 — Optional Module: Placement
-- Depends on: 16_transport.sql
-- =====================================================================

-- ---------------------------------------------------------------------
-- companies
-- ---------------------------------------------------------------------
CREATE TABLE companies (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id      UUID NOT NULL REFERENCES tenants(id),
    name           VARCHAR(255) NOT NULL,
    website        VARCHAR(255),
    industry       VARCHAR(100),
    contact_email  VARCHAR(255),
    contact_phone  VARCHAR(20),
    logo_url       TEXT
);

-- ---------------------------------------------------------------------
-- placement_drives
-- ---------------------------------------------------------------------
CREATE TABLE placement_drives (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id           UUID NOT NULL REFERENCES tenants(id),
    company_id          UUID NOT NULL REFERENCES companies(id),
    title               VARCHAR(255) NOT NULL,
    job_description     TEXT,
    package_min         NUMERIC(12,2),
    package_max         NUMERIC(12,2),
    drive_date          DATE NOT NULL,
    application_deadline TIMESTAMPTZ NOT NULL,
    status              drive_status NOT NULL DEFAULT 'UPCOMING',
    created_by          UUID NOT NULL REFERENCES users(id)
);

CREATE INDEX idx_placement_drives_company_id ON placement_drives (company_id);
CREATE INDEX idx_placement_drives_status     ON placement_drives (status);

-- ---------------------------------------------------------------------
-- drive_eligibility
-- ---------------------------------------------------------------------
CREATE TABLE drive_eligibility (
    id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    drive_id             UUID NOT NULL REFERENCES placement_drives(id) ON DELETE CASCADE,
    min_percentage       NUMERIC(5,2),
    max_backlogs         INTEGER,
    department_ids       UUID[],
    graduation_year      INTEGER
);

-- ---------------------------------------------------------------------
-- placement_applications
-- ---------------------------------------------------------------------
CREATE TABLE placement_applications (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id      UUID NOT NULL REFERENCES tenants(id),
    drive_id       UUID NOT NULL REFERENCES placement_drives(id),
    student_id     UUID NOT NULL REFERENCES users(id),
    resume_url     TEXT,
    status         application_status NOT NULL DEFAULT 'APPLIED',
    applied_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_placement_applications UNIQUE (drive_id, student_id)
);

CREATE INDEX idx_placement_applications_student_id ON placement_applications (student_id);
CREATE INDEX idx_placement_applications_drive_id   ON placement_applications (drive_id);

-- ---------------------------------------------------------------------
-- interview_rounds
-- ---------------------------------------------------------------------
CREATE TABLE interview_rounds (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    application_id   UUID NOT NULL REFERENCES placement_applications(id) ON DELETE CASCADE,
    round_number     SMALLINT NOT NULL,
    round_name       VARCHAR(100) NOT NULL,
    scheduled_at     TIMESTAMPTZ,
    result           interview_result,
    feedback         TEXT,
    interviewer      VARCHAR(255)
);

CREATE INDEX idx_interview_rounds_application_id ON interview_rounds (application_id);

-- ---------------------------------------------------------------------
-- placement_offers
-- ---------------------------------------------------------------------
CREATE TABLE placement_offers (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id        UUID NOT NULL REFERENCES tenants(id),
    application_id   UUID NOT NULL REFERENCES placement_applications(id),
    package_offered  NUMERIC(12,2) NOT NULL,
    designation      VARCHAR(255),
    offer_letter_url TEXT,
    status           offer_status NOT NULL DEFAULT 'ISSUED',
    issued_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_placement_offers_application_id ON placement_offers (application_id);
