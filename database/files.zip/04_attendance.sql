-- =====================================================================
-- 04_attendance.sql
-- Layer 4 — Core Module: Attendance
-- Depends on: 03_institution_structure.sql
-- =====================================================================

-- ---------------------------------------------------------------------
-- attendance_sessions
-- ---------------------------------------------------------------------
CREATE TABLE attendance_sessions (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id         UUID NOT NULL REFERENCES tenants(id),
    subject_id        UUID NOT NULL REFERENCES subjects(id),
    class_id          UUID NOT NULL REFERENCES classes(id),
    teacher_id        UUID NOT NULL REFERENCES users(id),
    academic_year_id  UUID NOT NULL REFERENCES academic_years(id),
    date              DATE NOT NULL,
    period_label      VARCHAR(30) NOT NULL,
    start_time        TIME,
    end_time          TIME,
    total_present     INTEGER NOT NULL DEFAULT 0,
    total_absent      INTEGER NOT NULL DEFAULT 0,
    notes             TEXT,
    is_locked         BOOLEAN NOT NULL DEFAULT FALSE,
    locked_at         TIMESTAMPTZ,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_att_sessions UNIQUE (tenant_id, subject_id, class_id, date, period_label)
);

CREATE INDEX idx_att_sessions_class_date  ON attendance_sessions (class_id, date);
CREATE INDEX idx_att_sessions_teacher_id  ON attendance_sessions (teacher_id);
CREATE INDEX idx_att_sessions_academic_year ON attendance_sessions (academic_year_id);

-- ---------------------------------------------------------------------
-- attendance_records
-- ---------------------------------------------------------------------
CREATE TABLE attendance_records (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id         UUID NOT NULL REFERENCES tenants(id),
    session_id        UUID NOT NULL REFERENCES attendance_sessions(id) ON DELETE CASCADE,
    student_id        UUID NOT NULL REFERENCES users(id),
    status            attendance_status NOT NULL,
    late_by_minutes   INTEGER,
    remarks           VARCHAR(255),
    marked_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_by        UUID REFERENCES users(id),
    CONSTRAINT uq_att_records_session_student UNIQUE (session_id, student_id)
);

CREATE INDEX idx_att_records_session_id      ON attendance_records (session_id);
CREATE INDEX idx_att_records_student_id      ON attendance_records (student_id);
CREATE INDEX idx_att_records_status          ON attendance_records (status);
CREATE INDEX idx_att_records_student_status  ON attendance_records (student_id, status);

-- ---------------------------------------------------------------------
-- attendance_leaves
-- ---------------------------------------------------------------------
CREATE TABLE attendance_leaves (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id      UUID NOT NULL REFERENCES tenants(id),
    student_id     UUID NOT NULL REFERENCES users(id),
    class_id       UUID NOT NULL REFERENCES classes(id),
    from_date      DATE NOT NULL,
    to_date        DATE NOT NULL,
    reason         TEXT NOT NULL,
    document_url   TEXT,
    status         leave_status NOT NULL DEFAULT 'PENDING',
    reviewed_by    UUID REFERENCES users(id),
    reviewed_at    TIMESTAMPTZ,
    created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_att_leaves_student_id ON attendance_leaves (student_id);
CREATE INDEX idx_att_leaves_class_id   ON attendance_leaves (class_id);
CREATE INDEX idx_att_leaves_status     ON attendance_leaves (status);
