-- =====================================================================
-- 00_extensions_and_enums.sql
-- ERP + LMS Platform — PostgreSQL 18
-- Run this FIRST. Sets up extensions + every enum type used later.
-- =====================================================================

-- gen_random_uuid() is built into PostgreSQL 13+ core (pgcrypto no longer
-- required for it), but we still enable pgcrypto/uuid-ossp in case any
-- tooling (Prisma, etc.) expects them to exist.
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ---------------------------------------------------------------------
-- Tenant / Platform
-- ---------------------------------------------------------------------
CREATE TYPE tenant_type         AS ENUM ('SCHOOL', 'COLLEGE');
CREATE TYPE subscription_status AS ENUM ('TRIAL', 'ACTIVE', 'PAST_DUE', 'CANCELLED');
CREATE TYPE platform_role       AS ENUM ('SUPER_ADMIN', 'SUPPORT', 'SALES', 'FINANCE');

-- ---------------------------------------------------------------------
-- RBAC
-- ---------------------------------------------------------------------
CREATE TYPE scope_level         AS ENUM ('PLATFORM', 'INSTITUTION', 'DEPARTMENT', 'CLASS', 'SUBJECT', 'SELF', 'CHILD');
CREATE TYPE permission_action   AS ENUM ('CREATE', 'READ', 'UPDATE', 'DELETE');
CREATE TYPE permission_scope    AS ENUM ('ALL', 'DEPARTMENT', 'CLASS', 'SUBJECT', 'OWN', 'CHILD');

-- ---------------------------------------------------------------------
-- Users
-- ---------------------------------------------------------------------
CREATE TYPE gender              AS ENUM ('MALE', 'FEMALE', 'OTHER');
CREATE TYPE enrollment_status   AS ENUM ('ACTIVE', 'TRANSFERRED', 'DROPPED', 'COMPLETED');

-- ---------------------------------------------------------------------
-- Subjects
-- ---------------------------------------------------------------------
CREATE TYPE subject_type        AS ENUM ('THEORY', 'PRACTICAL', 'ELECTIVE', 'PROJECT');

-- ---------------------------------------------------------------------
-- Attendance
-- ---------------------------------------------------------------------
CREATE TYPE attendance_status   AS ENUM ('PRESENT', 'ABSENT', 'LATE', 'EXCUSED');
CREATE TYPE leave_status        AS ENUM ('PENDING', 'APPROVED', 'REJECTED', 'CANCELLED');

-- ---------------------------------------------------------------------
-- Examination
-- ---------------------------------------------------------------------
CREATE TYPE exam_type           AS ENUM ('MCQ', 'DESCRIPTIVE', 'MIXED', 'QUIZ');
CREATE TYPE exam_mode           AS ENUM ('ONLINE', 'OFFLINE');
CREATE TYPE exam_status         AS ENUM ('DRAFT', 'PUBLISHED', 'ONGOING', 'COMPLETED', 'RESULTS_RELEASED', 'CANCELLED');
CREATE TYPE question_type       AS ENUM ('MCQ', 'SHORT_ANSWER', 'LONG_ANSWER', 'TRUE_FALSE', 'FILL_BLANK', 'MATCH');
CREATE TYPE difficulty_level    AS ENUM ('EASY', 'MEDIUM', 'HARD');
CREATE TYPE attempt_status      AS ENUM ('IN_PROGRESS', 'SUBMITTED', 'GRADED', 'MALPRACTICE');

-- ---------------------------------------------------------------------
-- Assignment
-- ---------------------------------------------------------------------
CREATE TYPE assignment_type     AS ENUM ('REGULAR', 'MILESTONE', 'GROUP');
CREATE TYPE assignment_status   AS ENUM ('DRAFT', 'PUBLISHED', 'CLOSED');
CREATE TYPE submission_status   AS ENUM ('SUBMITTED', 'UNDER_REVIEW', 'APPROVED', 'REJECTED', 'RESUBMIT_REQUESTED');

-- ---------------------------------------------------------------------
-- Notices
-- ---------------------------------------------------------------------
CREATE TYPE notice_scope        AS ENUM ('INSTITUTION', 'DEPARTMENT', 'CLASS', 'HOSTEL', 'TRANSPORT');
CREATE TYPE notice_priority     AS ENUM ('NORMAL', 'IMPORTANT', 'URGENT');

-- ---------------------------------------------------------------------
-- Content
-- ---------------------------------------------------------------------
CREATE TYPE content_type        AS ENUM ('PDF', 'VIDEO', 'SLIDE', 'LINK', 'IMAGE', 'AUDIO', 'ZIP');

-- ---------------------------------------------------------------------
-- Results
-- ---------------------------------------------------------------------
CREATE TYPE result_outcome      AS ENUM ('PASS', 'FAIL', 'WITHHELD', 'ABSENT');

-- ---------------------------------------------------------------------
-- Timetable
-- ---------------------------------------------------------------------
CREATE TYPE slot_type           AS ENUM ('CLASS', 'BREAK', 'LAB', 'ACTIVITY');

-- ---------------------------------------------------------------------
-- Library
-- ---------------------------------------------------------------------
CREATE TYPE book_condition      AS ENUM ('GOOD', 'FAIR', 'DAMAGED', 'LOST');

-- ---------------------------------------------------------------------
-- Hostel
-- ---------------------------------------------------------------------
CREATE TYPE allotment_status    AS ENUM ('ACTIVE', 'VACATED', 'TRANSFERRED');
CREATE TYPE complaint_status    AS ENUM ('OPEN', 'IN_PROGRESS', 'RESOLVED');

-- ---------------------------------------------------------------------
-- Placement
-- ---------------------------------------------------------------------
CREATE TYPE drive_status        AS ENUM ('UPCOMING', 'OPEN', 'ONGOING', 'COMPLETED', 'CANCELLED');
CREATE TYPE application_status  AS ENUM ('APPLIED', 'SHORTLISTED', 'REJECTED', 'PLACED', 'WITHDRAWN');
CREATE TYPE interview_result    AS ENUM ('PASS', 'FAIL', 'ON_HOLD', 'ABSENT');
CREATE TYPE offer_status        AS ENUM ('ISSUED', 'ACCEPTED', 'DECLINED', 'REVOKED');

-- ---------------------------------------------------------------------
-- HR
-- ---------------------------------------------------------------------
CREATE TYPE employment_type     AS ENUM ('FULL_TIME', 'PART_TIME', 'CONTRACT', 'VISITING');
CREATE TYPE payroll_status      AS ENUM ('DRAFT', 'PROCESSED', 'PAID', 'LOCKED');
CREATE TYPE appraisal_status    AS ENUM ('PLANNED', 'OPEN', 'CLOSED', 'PENDING');

-- ---------------------------------------------------------------------
-- Admission
-- ---------------------------------------------------------------------
CREATE TYPE admission_status         AS ENUM ('SUBMITTED', 'UNDER_REVIEW', 'SHORTLISTED', 'WAITLISTED', 'ADMITTED', 'REJECTED');
CREATE TYPE admission_cycle_status   AS ENUM ('UPCOMING', 'OPEN', 'CLOSED', 'COMPLETED');

-- ---------------------------------------------------------------------
-- Finance
-- ---------------------------------------------------------------------
CREATE TYPE fee_status           AS ENUM ('UNPAID', 'PARTIAL', 'PAID', 'WAIVED');
CREATE TYPE installment_status   AS ENUM ('PENDING', 'PAID', 'OVERDUE', 'WAIVED');
CREATE TYPE payment_mode         AS ENUM ('CASH', 'ONLINE', 'CHEQUE', 'DD', 'UPI');
CREATE TYPE scholarship_type     AS ENUM ('PERCENTAGE', 'FIXED_AMOUNT', 'FULL_WAIVER');

-- ---------------------------------------------------------------------
-- Inventory
-- ---------------------------------------------------------------------
CREATE TYPE stock_txn_type       AS ENUM ('STOCK_IN', 'STOCK_OUT', 'ADJUSTMENT', 'RETURN');
CREATE TYPE po_status             AS ENUM ('DRAFT', 'SENT', 'ACKNOWLEDGED', 'DELIVERED', 'CANCELLED');

-- ---------------------------------------------------------------------
-- Support
-- ---------------------------------------------------------------------
CREATE TYPE ticket_priority      AS ENUM ('LOW', 'MEDIUM', 'HIGH', 'CRITICAL');
CREATE TYPE ticket_status        AS ENUM ('OPEN', 'IN_PROGRESS', 'RESOLVED', 'CLOSED');
