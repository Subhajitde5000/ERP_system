-- =====================================================================
-- 21_notifications_and_audit.sql
-- Layer 8 — System Tables (Notifications & Audit)
-- Depends on: 20_inventory.sql
-- Run this LAST.
-- =====================================================================

-- ---------------------------------------------------------------------
-- notifications
-- ---------------------------------------------------------------------
CREATE TABLE notifications (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id      UUID NOT NULL REFERENCES tenants(id),
    user_id        UUID NOT NULL REFERENCES users(id),
    title          VARCHAR(255) NOT NULL,
    body           TEXT,
    type           VARCHAR(50) NOT NULL,
    link           TEXT,
    is_read        BOOLEAN NOT NULL DEFAULT FALSE,
    read_at        TIMESTAMPTZ,
    created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_notifications_user_id ON notifications (user_id);
CREATE INDEX idx_notifications_unread  ON notifications (user_id) WHERE is_read = FALSE;

-- ---------------------------------------------------------------------
-- device_tokens
-- ---------------------------------------------------------------------
CREATE TABLE device_tokens (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id        UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token          TEXT NOT NULL,
    platform       VARCHAR(20) NOT NULL,
    created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_device_tokens_token UNIQUE (token)
);

CREATE INDEX idx_device_tokens_user_id ON device_tokens (user_id);

-- ---------------------------------------------------------------------
-- audit_logs
-- ---------------------------------------------------------------------
-- Note: user_id is intentionally NOT a foreign key (per design), so audit
-- history survives even if the referenced user row is later hard-deleted.
CREATE TABLE audit_logs (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id      UUID NOT NULL REFERENCES tenants(id),
    user_id        UUID NOT NULL,
    action         VARCHAR(50) NOT NULL,
    entity_type    VARCHAR(100) NOT NULL,
    entity_id      UUID,
    old_values     JSONB,
    new_values     JSONB,
    ip_address     INET,
    user_agent     TEXT,
    created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_audit_logs_tenant_id            ON audit_logs (tenant_id);
CREATE INDEX idx_audit_logs_user_id              ON audit_logs (user_id);
CREATE INDEX idx_audit_logs_entity_type_entity_id ON audit_logs (entity_type, entity_id);
CREATE INDEX idx_audit_logs_created_at            ON audit_logs (created_at);
