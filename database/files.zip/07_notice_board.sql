-- =====================================================================
-- 07_notice_board.sql
-- Layer 4 — Core Module: Notice Board
-- Depends on: 06_assignment.sql
-- =====================================================================

-- ---------------------------------------------------------------------
-- notices
-- ---------------------------------------------------------------------
CREATE TABLE notices (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id      UUID NOT NULL REFERENCES tenants(id),
    title          VARCHAR(255) NOT NULL,
    body           TEXT NOT NULL,
    author_id      UUID NOT NULL REFERENCES users(id),
    target_scope   notice_scope NOT NULL,
    target_id      UUID,
    priority       notice_priority NOT NULL DEFAULT 'NORMAL',
    is_pinned      BOOLEAN NOT NULL DEFAULT FALSE,
    published_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at     TIMESTAMPTZ,
    created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted_at     TIMESTAMPTZ
);

CREATE INDEX idx_notices_tenant_scope  ON notices (tenant_id, target_scope, target_id);
CREATE INDEX idx_notices_published_at  ON notices (published_at);
CREATE INDEX idx_notices_expires_at    ON notices (expires_at) WHERE expires_at IS NOT NULL;

-- ---------------------------------------------------------------------
-- notice_attachments
-- ---------------------------------------------------------------------
CREATE TABLE notice_attachments (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    notice_id         UUID NOT NULL REFERENCES notices(id) ON DELETE CASCADE,
    file_name         VARCHAR(255) NOT NULL,
    file_key          TEXT NOT NULL,
    file_size_bytes   BIGINT NOT NULL,
    mime_type         VARCHAR(100) NOT NULL
);

CREATE INDEX idx_notice_attachments_notice_id ON notice_attachments (notice_id);

-- ---------------------------------------------------------------------
-- notice_reads
-- ---------------------------------------------------------------------
CREATE TABLE notice_reads (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    notice_id   UUID NOT NULL REFERENCES notices(id) ON DELETE CASCADE,
    user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    read_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_notice_reads UNIQUE (notice_id, user_id)
);

CREATE INDEX idx_notice_reads_notice_id ON notice_reads (notice_id);
CREATE INDEX idx_notice_reads_user_id   ON notice_reads (user_id);
