-- =====================================================================
-- 06_assignment.sql
-- Layer 4 — Core Module: Assignment & Milestone
-- Depends on: 05_examination.sql
-- =====================================================================

-- ---------------------------------------------------------------------
-- assignments
-- ---------------------------------------------------------------------
CREATE TABLE assignments (
    id                       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id                UUID NOT NULL REFERENCES tenants(id),
    title                    VARCHAR(255) NOT NULL,
    description              TEXT NOT NULL,
    subject_id               UUID NOT NULL REFERENCES subjects(id),
    class_id                 UUID NOT NULL REFERENCES classes(id),
    academic_year_id         UUID NOT NULL REFERENCES academic_years(id),
    teacher_id               UUID NOT NULL REFERENCES users(id),
    type                     assignment_type NOT NULL,
    total_marks              INTEGER NOT NULL,
    passing_marks            INTEGER NOT NULL,
    due_date                 TIMESTAMPTZ NOT NULL,
    allow_late_submission    BOOLEAN NOT NULL DEFAULT FALSE,
    late_penalty_percent     INTEGER NOT NULL DEFAULT 0,
    max_file_size_mb         INTEGER NOT NULL DEFAULT 10,
    allowed_file_types       TEXT[] NOT NULL DEFAULT '{pdf,doc,docx,zip}',
    status                   assignment_status NOT NULL DEFAULT 'DRAFT',
    instructions_url         TEXT,
    created_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at               TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_assignments_class_id   ON assignments (class_id);
CREATE INDEX idx_assignments_teacher_id ON assignments (teacher_id);
CREATE INDEX idx_assignments_due_date   ON assignments (due_date);
CREATE INDEX idx_assignments_class      ON assignments (class_id, due_date);

-- ---------------------------------------------------------------------
-- milestones
-- ---------------------------------------------------------------------
CREATE TABLE milestones (
    id                          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    assignment_id               UUID NOT NULL REFERENCES assignments(id) ON DELETE CASCADE,
    title                       VARCHAR(255) NOT NULL,
    description                 TEXT,
    sort_order                  INTEGER NOT NULL,
    marks                       INTEGER NOT NULL,
    due_date                    TIMESTAMPTZ,
    unlock_after_milestone_id   UUID REFERENCES milestones(id),
    created_at                  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_milestones_assignment_id ON milestones (assignment_id);

-- ---------------------------------------------------------------------
-- submissions
-- ---------------------------------------------------------------------
CREATE TABLE submissions (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id         UUID NOT NULL REFERENCES tenants(id),
    assignment_id     UUID NOT NULL REFERENCES assignments(id),
    milestone_id      UUID REFERENCES milestones(id),
    student_id        UUID NOT NULL REFERENCES users(id),
    text_response     TEXT,
    submitted_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    is_late           BOOLEAN NOT NULL DEFAULT FALSE,
    late_by_minutes   INTEGER,
    score             NUMERIC(5,2),
    grade             VARCHAR(5),
    feedback          TEXT,
    status            submission_status NOT NULL DEFAULT 'SUBMITTED',
    reviewed_by       UUID REFERENCES users(id),
    reviewed_at       TIMESTAMPTZ,
    version           INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT uq_submissions UNIQUE (assignment_id, milestone_id, student_id, version)
);

CREATE INDEX idx_submissions_assignment_id ON submissions (assignment_id);
CREATE INDEX idx_submissions_student_id    ON submissions (student_id);
CREATE INDEX idx_submissions_status        ON submissions (status);
CREATE INDEX idx_submissions_assignment    ON submissions (assignment_id, student_id);

-- ---------------------------------------------------------------------
-- submission_files
-- ---------------------------------------------------------------------
CREATE TABLE submission_files (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    submission_id     UUID NOT NULL REFERENCES submissions(id) ON DELETE CASCADE,
    file_name         VARCHAR(255) NOT NULL,
    file_key          TEXT NOT NULL,
    file_size_bytes   BIGINT NOT NULL,
    mime_type         VARCHAR(100) NOT NULL,
    uploaded_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_submission_files_submission_id ON submission_files (submission_id);
