-- =====================================================================
-- 10_results_grade_cards.sql
-- Layer 4 — Core Module: Results & Grade Cards
-- Depends on: 09_content_upload.sql
-- =====================================================================

-- ---------------------------------------------------------------------
-- result_publications
-- ---------------------------------------------------------------------
CREATE TABLE result_publications (
    id                        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id                 UUID NOT NULL REFERENCES tenants(id),
    title                     VARCHAR(255) NOT NULL,
    academic_year_id          UUID NOT NULL REFERENCES academic_years(id),
    class_id                  UUID REFERENCES classes(id),
    exam_ids                  UUID[] NOT NULL,
    published_by              UUID NOT NULL REFERENCES users(id),
    published_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    is_visible_to_students    BOOLEAN NOT NULL DEFAULT FALSE
);

-- ---------------------------------------------------------------------
-- student_results
-- ---------------------------------------------------------------------
CREATE TABLE student_results (
    id                      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL REFERENCES tenants(id),
    publication_id          UUID NOT NULL REFERENCES result_publications(id),
    student_id              UUID NOT NULL REFERENCES users(id),
    class_id                UUID NOT NULL REFERENCES classes(id),
    total_marks_obtained    NUMERIC(8,2) NOT NULL,
    total_marks_possible    NUMERIC(8,2) NOT NULL,
    percentage              NUMERIC(5,2) NOT NULL,
    grade                   VARCHAR(5) NOT NULL,
    rank                    INTEGER,
    result                  result_outcome NOT NULL,
    subject_scores          JSONB NOT NULL,
    remarks                 TEXT,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_student_results UNIQUE (publication_id, student_id)
);

CREATE INDEX idx_results_publication  ON student_results (publication_id);
CREATE INDEX idx_results_student_id   ON student_results (student_id);
CREATE INDEX idx_results_class_id     ON student_results (class_id);

-- ---------------------------------------------------------------------
-- grade_cards
-- ---------------------------------------------------------------------
CREATE TABLE grade_cards (
    id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id            UUID NOT NULL REFERENCES tenants(id),
    student_result_id    UUID NOT NULL REFERENCES student_results(id),
    file_key             TEXT NOT NULL,
    generated_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    template_version     VARCHAR(20) NOT NULL DEFAULT '1.0'
);

CREATE INDEX idx_grade_cards_student_result_id ON grade_cards (student_result_id);
