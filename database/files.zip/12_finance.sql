-- =====================================================================
-- 12_finance.sql
-- Layer 6 — Platform ERP Tables (Finance Module)
-- Depends on: 11_timetable.sql
-- =====================================================================

-- ---------------------------------------------------------------------
-- fee_structures
-- ---------------------------------------------------------------------
CREATE TABLE fee_structures (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id           UUID NOT NULL REFERENCES tenants(id),
    academic_year_id    UUID NOT NULL REFERENCES academic_years(id),
    name                VARCHAR(100) NOT NULL,
    applicable_to       UUID[],
    total_amount        NUMERIC(12,2) NOT NULL,
    is_active           BOOLEAN NOT NULL DEFAULT TRUE,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ---------------------------------------------------------------------
-- fee_heads
-- ---------------------------------------------------------------------
CREATE TABLE fee_heads (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    structure_id    UUID NOT NULL REFERENCES fee_structures(id) ON DELETE CASCADE,
    tenant_id       UUID NOT NULL REFERENCES tenants(id),
    name            VARCHAR(100) NOT NULL,
    amount          NUMERIC(12,2) NOT NULL,
    is_refundable   BOOLEAN NOT NULL DEFAULT FALSE,
    sort_order      INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX idx_fee_heads_structure_id ON fee_heads (structure_id);

-- ---------------------------------------------------------------------
-- student_fee_accounts
-- ---------------------------------------------------------------------
CREATE TABLE student_fee_accounts (
    id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id             UUID NOT NULL REFERENCES tenants(id),
    student_id            UUID NOT NULL REFERENCES users(id),
    academic_year_id      UUID NOT NULL REFERENCES academic_years(id),
    structure_id          UUID NOT NULL REFERENCES fee_structures(id),
    total_fee             NUMERIC(12,2) NOT NULL,
    concession_amount     NUMERIC(12,2) NOT NULL DEFAULT 0,
    scholarship_amount    NUMERIC(12,2) NOT NULL DEFAULT 0,
    net_payable           NUMERIC(12,2) NOT NULL,
    total_paid             NUMERIC(12,2) NOT NULL DEFAULT 0,
    balance_due            NUMERIC(12,2) NOT NULL,
    status                 fee_status NOT NULL DEFAULT 'UNPAID',
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_student_fee_accounts UNIQUE (student_id, academic_year_id)
);

-- ---------------------------------------------------------------------
-- fee_installments
-- ---------------------------------------------------------------------
CREATE TABLE fee_installments (
    id                     UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    fee_account_id         UUID NOT NULL REFERENCES student_fee_accounts(id),
    tenant_id              UUID NOT NULL REFERENCES tenants(id),
    installment_number     SMALLINT NOT NULL,
    label                  VARCHAR(50) NOT NULL,
    amount                 NUMERIC(12,2) NOT NULL,
    due_date               DATE NOT NULL,
    paid_amount            NUMERIC(12,2) NOT NULL DEFAULT 0,
    status                 installment_status NOT NULL DEFAULT 'PENDING',
    late_fine              NUMERIC(8,2) NOT NULL DEFAULT 0
);

CREATE INDEX idx_installments_due            ON fee_installments (due_date, status);
CREATE INDEX idx_fee_installments_account_id ON fee_installments (fee_account_id);

-- ---------------------------------------------------------------------
-- fee_payments
-- ---------------------------------------------------------------------
CREATE TABLE fee_payments (
    id                       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id                UUID NOT NULL REFERENCES tenants(id),
    fee_account_id           UUID NOT NULL REFERENCES student_fee_accounts(id),
    installment_id           UUID REFERENCES fee_installments(id),
    student_id               UUID NOT NULL REFERENCES users(id),
    amount                   NUMERIC(12,2) NOT NULL,
    payment_mode             payment_mode NOT NULL,
    transaction_reference    VARCHAR(255),
    payment_date             DATE NOT NULL,
    receipt_number           VARCHAR(50) NOT NULL,
    collected_by              UUID NOT NULL REFERENCES users(id),
    notes                     TEXT,
    created_at                TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_fee_payments_receipt UNIQUE (tenant_id, receipt_number)
);

CREATE INDEX idx_fee_payments_student  ON fee_payments (student_id);
CREATE INDEX idx_fee_payments_date     ON fee_payments (payment_date);

-- ---------------------------------------------------------------------
-- scholarships
-- ---------------------------------------------------------------------
CREATE TABLE scholarships (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id    UUID NOT NULL REFERENCES tenants(id),
    name         VARCHAR(255) NOT NULL,
    type         scholarship_type NOT NULL,
    value        NUMERIC(10,2) NOT NULL,
    criteria     TEXT,
    is_active    BOOLEAN NOT NULL DEFAULT TRUE
);

-- ---------------------------------------------------------------------
-- scholarship_grants
-- ---------------------------------------------------------------------
CREATE TABLE scholarship_grants (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id           UUID NOT NULL REFERENCES tenants(id),
    scholarship_id      UUID NOT NULL REFERENCES scholarships(id),
    student_id          UUID NOT NULL REFERENCES users(id),
    fee_account_id      UUID NOT NULL REFERENCES student_fee_accounts(id),
    amount_granted      NUMERIC(12,2) NOT NULL,
    academic_year_id    UUID NOT NULL REFERENCES academic_years(id),
    granted_by          UUID REFERENCES users(id),
    granted_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    remarks             TEXT
);

CREATE INDEX idx_scholarship_grants_student_id ON scholarship_grants (student_id);
