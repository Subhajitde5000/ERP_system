-- =====================================================================
-- 09_content_upload.sql
-- Layer 4 — Core Module: Content Upload
-- Depends on: 08_discussion_forum.sql
-- =====================================================================

-- ---------------------------------------------------------------------
-- content_items
-- ---------------------------------------------------------------------
CREATE TABLE content_items (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id           UUID NOT NULL REFERENCES tenants(id),
    title               VARCHAR(255) NOT NULL,
    description         TEXT,
    subject_id          UUID NOT NULL REFERENCES subjects(id),
    class_id            UUID NOT NULL REFERENCES classes(id),
    uploaded_by         UUID NOT NULL REFERENCES users(id),
    content_type        content_type NOT NULL,
    file_key            TEXT,
    external_url        TEXT,
    file_size_bytes     BIGINT,
    duration_seconds    INTEGER,
    chapter             VARCHAR(100),
    sort_order          INTEGER NOT NULL DEFAULT 0,
    is_visible          BOOLEAN NOT NULL DEFAULT TRUE,
    download_count      INTEGER NOT NULL DEFAULT 0,
    view_count          INTEGER NOT NULL DEFAULT 0,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted_at          TIMESTAMPTZ
);

CREATE INDEX idx_content_subject_id     ON content_items (subject_id);
CREATE INDEX idx_content_class_id       ON content_items (class_id);
CREATE INDEX idx_content_chapter        ON content_items (subject_id, chapter);
CREATE INDEX idx_content_subject_class  ON content_items (subject_id, class_id, is_visible);

-- ---------------------------------------------------------------------
-- content_tags
-- ---------------------------------------------------------------------
CREATE TABLE content_tags (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    content_id   UUID NOT NULL REFERENCES content_items(id) ON DELETE CASCADE,
    tag          VARCHAR(50) NOT NULL,
    CONSTRAINT uq_content_tags UNIQUE (content_id, tag)
);

-- ---------------------------------------------------------------------
-- content_access_logs
-- ---------------------------------------------------------------------
CREATE TABLE content_access_logs (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    content_id    UUID NOT NULL REFERENCES content_items(id),
    user_id       UUID NOT NULL REFERENCES users(id),
    action        VARCHAR(10) NOT NULL,
    accessed_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_content_access_content_id ON content_access_logs (content_id);
CREATE INDEX idx_content_access_user_id    ON content_access_logs (user_id);
