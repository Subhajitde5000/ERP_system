-- =====================================================================
-- 05_examination.sql
-- Layer 4 — Core Module: Examination
-- Depends on: 04_attendance.sql
-- =====================================================================

-- ---------------------------------------------------------------------
-- exams
-- ---------------------------------------------------------------------
CREATE TABLE exams (
    id                       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id                UUID NOT NULL REFERENCES tenants(id),
    title                    VARCHAR(255) NOT NULL,
    subject_id               UUID NOT NULL REFERENCES subjects(id),
    class_id                 UUID NOT NULL REFERENCES classes(id),
    academic_year_id         UUID NOT NULL REFERENCES academic_years(id),
    exam_type                exam_type NOT NULL,
    mode                     exam_mode NOT NULL DEFAULT 'ONLINE',
    total_marks              INTEGER NOT NULL,
    passing_marks            INTEGER NOT NULL,
    duration_minutes         INTEGER NOT NULL,
    instructions             TEXT,
    scheduled_at             TIMESTAMPTZ NOT NULL,
    window_end_at            TIMESTAMPTZ,
    results_release_at       TIMESTAMPTZ,
    status                   exam_status NOT NULL DEFAULT 'DRAFT',
    allow_review             BOOLEAN NOT NULL DEFAULT FALSE,
    shuffle_questions        BOOLEAN NOT NULL DEFAULT FALSE,
    show_score_immediately   BOOLEAN NOT NULL DEFAULT FALSE,
    created_by               UUID NOT NULL REFERENCES users(id),
    created_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at               TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_exams_class_id      ON exams (class_id);
CREATE INDEX idx_exams_subject_id    ON exams (subject_id);
CREATE INDEX idx_exams_status        ON exams (status);
CREATE INDEX idx_exams_scheduled_at  ON exams (scheduled_at);
CREATE INDEX idx_exams_class_subject ON exams (class_id, subject_id);
CREATE INDEX idx_exams_status_date   ON exams (status, scheduled_at);

-- ---------------------------------------------------------------------
-- exam_sections
-- ---------------------------------------------------------------------
CREATE TABLE exam_sections (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    exam_id      UUID NOT NULL REFERENCES exams(id) ON DELETE CASCADE,
    title        VARCHAR(100) NOT NULL,
    description  TEXT,
    max_marks    INTEGER NOT NULL,
    sort_order   INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX idx_exam_sections_exam_id ON exam_sections (exam_id);

-- ---------------------------------------------------------------------
-- questions
-- ---------------------------------------------------------------------
CREATE TABLE questions (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    exam_id          UUID NOT NULL REFERENCES exams(id) ON DELETE CASCADE,
    section_id       UUID REFERENCES exam_sections(id),
    text             TEXT NOT NULL,
    rich_text        JSONB,
    question_type    question_type NOT NULL,
    marks            NUMERIC(5,2) NOT NULL,
    negative_marks   NUMERIC(5,2) NOT NULL DEFAULT 0,
    image_url        TEXT,
    explanation      TEXT,
    difficulty       difficulty_level,
    sort_order       INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX idx_questions_exam_id ON questions (exam_id);
CREATE INDEX idx_questions_exam    ON questions (exam_id, sort_order);

-- ---------------------------------------------------------------------
-- question_options
-- ---------------------------------------------------------------------
CREATE TABLE question_options (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    question_id  UUID NOT NULL REFERENCES questions(id) ON DELETE CASCADE,
    text         TEXT NOT NULL,
    image_url    TEXT,
    is_correct   BOOLEAN NOT NULL DEFAULT FALSE,
    sort_order   INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX idx_question_options_question_id ON question_options (question_id);

-- ---------------------------------------------------------------------
-- exam_hall_allocations
-- ---------------------------------------------------------------------
CREATE TABLE exam_hall_allocations (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id        UUID NOT NULL REFERENCES tenants(id),
    exam_id          UUID NOT NULL REFERENCES exams(id),
    room_no          VARCHAR(50) NOT NULL,
    invigilator_id   UUID REFERENCES users(id),
    student_ids      UUID[] NOT NULL,
    capacity         INTEGER NOT NULL,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_exam_hall_allocations_exam_id ON exam_hall_allocations (exam_id);

-- ---------------------------------------------------------------------
-- exam_attempts
-- ---------------------------------------------------------------------
CREATE TABLE exam_attempts (
    id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id          UUID NOT NULL REFERENCES tenants(id),
    exam_id            UUID NOT NULL REFERENCES exams(id),
    student_id         UUID NOT NULL REFERENCES users(id),
    started_at         TIMESTAMPTZ NOT NULL,
    submitted_at       TIMESTAMPTZ,
    auto_submitted     BOOLEAN NOT NULL DEFAULT FALSE,
    total_score        NUMERIC(8,2),
    percentage         NUMERIC(5,2),
    grade              VARCHAR(5),
    status             attempt_status NOT NULL DEFAULT 'IN_PROGRESS',
    tab_switch_count   INTEGER NOT NULL DEFAULT 0,
    ip_address         INET,
    device_info        TEXT,
    created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_exam_attempts_exam_student UNIQUE (exam_id, student_id)
);

CREATE INDEX idx_attempts_exam_id       ON exam_attempts (exam_id);
CREATE INDEX idx_attempts_student_id    ON exam_attempts (student_id);
CREATE INDEX idx_attempts_status        ON exam_attempts (status);
CREATE INDEX idx_attempts_exam_student  ON exam_attempts (exam_id, student_id);

-- ---------------------------------------------------------------------
-- answers
-- ---------------------------------------------------------------------
CREATE TABLE answers (
    id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    attempt_id           UUID NOT NULL REFERENCES exam_attempts(id) ON DELETE CASCADE,
    question_id          UUID NOT NULL REFERENCES questions(id),
    selected_option_id   UUID REFERENCES question_options(id),
    text_answer          TEXT,
    matched_pairs        JSONB,
    score                NUMERIC(5,2),
    is_auto_graded       BOOLEAN NOT NULL DEFAULT FALSE,
    feedback             TEXT,
    graded_by            UUID REFERENCES users(id),
    graded_at            TIMESTAMPTZ,
    answered_at          TIMESTAMPTZ,
    CONSTRAINT uq_answers_attempt_question UNIQUE (attempt_id, question_id)
);

CREATE INDEX idx_answers_attempt_id ON answers (attempt_id);

-- ---------------------------------------------------------------------
-- malpractice_logs
-- ---------------------------------------------------------------------
CREATE TABLE malpractice_logs (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id      UUID NOT NULL REFERENCES tenants(id),
    attempt_id     UUID NOT NULL REFERENCES exam_attempts(id),
    student_id     UUID NOT NULL REFERENCES users(id),
    type           VARCHAR(50) NOT NULL,
    description    TEXT,
    evidence_url   TEXT,
    action_taken   VARCHAR(255),
    logged_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    handled_by     UUID REFERENCES users(id)
);

CREATE INDEX idx_malpractice_logs_attempt_id ON malpractice_logs (attempt_id);
CREATE INDEX idx_malpractice_logs_student_id ON malpractice_logs (student_id);
